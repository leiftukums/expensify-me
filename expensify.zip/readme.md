# Git commands

git init - create a git repo
git status - view the changes to our project code
git add - add files to staging area
git commit - creates a new commit with files from staging area
git log - view recent commits